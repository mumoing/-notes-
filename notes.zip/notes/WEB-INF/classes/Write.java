package write;
import java.io.*;
public class Write{
	public void keep(String path,String content)throws Exception
 {
	 File f=new File(path);
	 OutputStream out=new FileOutputStream(f);
	 byte b[]=content.getBytes();
	 out.write(b);
	 out.close();
 }
}