package time;
import java.io.*;
import java.util.*;
import java.text.*;
public class Time {
public static void add(String name,String path)
{
	DateFormat df=DateFormat.getDateInstance();
	String time=df.format(new Date());
	String in="\r\n"+name+":"+time+" ";
	byte[] b=in.getBytes();
	File f=new File(path);
	try{
	OutputStream out=new FileOutputStream(f,true);
	out.write(b);
	out.close();
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	
	
	
}

public static String get(String name,String path)
{
	File f=new File(path);
	String result=null;
	try{
	InputStream in=new FileInputStream(f);
	byte b[]=new byte[(int)f.length()];
	in.read(b);
	result=new String(b);
	int idx=result.lastIndexOf(name);
	result=result.substring(idx+name.length()+1, idx+name.length()+11);
	in.close();
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	return result;
}
}
