package read;
import java.io.*;
public class Read{
	public static String read(String path)throws Exception
 {
	 File f=new File(path);
	 InputStream input=new FileInputStream(f);
	 byte b[]=new byte[(int)f.length()];
	 for(int i=0;i<b.length;i++)
	 {
		 b[i]=(byte)input.read();
	 }
	 input.close();
	 return new String(b);
 }
}