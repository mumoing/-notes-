function show(a,b){
 var re=document.getElementsByClassName(a);
 var i;
 for(i=0;i<re.length;i++)
 {
 	re[i].style.display="block";
 }
 var res=document.getElementsByClassName(b);
 
 for(i=0;i<res.length;i++)
 {
 	res[i].style.display="block";
 }

}

function hide(a,b){
 var re=document.getElementsByClassName(a);
 var i;
 for(i=0;i<re.length;i++)
 {
 	re[i].style.display="none";
 }

  var res=document.getElementsByClassName(b);
 
 for(i=0;i<res.length;i++)
 {
 	res[i].style.display="none";
 }
}


function shows(a){
 var re=document.getElementsByClassName(a);
 var i;
 for(i=0;i<re.length;i++)
 {
 	re[i].style.display="block";
 }


}

function hides(a){
 var re=document.getElementsByClassName(a);
 var i;
 for(i=0;i<re.length;i++)
 {
 	re[i].style.display="none";
 }
}

function change()
{
	var s=document.getElementById('manager').innerHTML;
	if(s=="进行管理")
	{
		show('delete','cancle');
		document.getElementById('manager').innerHTML="取消管理";
	}
	else
	{
		hide('delete','cancle')
		document.getElementById('manager').innerHTML="进行管理";
	}
}
function table()
{
	var name=prompt("请输入标签名");
	var x;
	if(name!=null&&name!="")
	{
		x=name;
		window.location.href="newtable.jsp?newpath="+x+"";
	}

}
function artcle()
{
	var name=prompt("请输入文件名");
	var x;
	if(name!=null&&name!="")
	{
		x=name;
		window.location.href="newartcle.jsp?newartcle="+x+"";
	}
}

var cook=document.cookie.split(';');
function manage()
{
    if(cook[0]=="fromdelete=1")
    {

    }
    else
    {
    	change();
    	document.cookie="fromdelete=1";
    }
}
function changecook() {
      // body...
       document.cookie='fromdelete=0';
    }